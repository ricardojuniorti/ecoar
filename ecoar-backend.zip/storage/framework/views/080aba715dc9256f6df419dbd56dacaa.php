<svg fill="none" stroke="currentColor" viewBox="0 0 24 24" <?php echo e($attributes); ?>>
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
</svg>
<?php /**PATH D:\laragon\www\ecoar-backend\vendor\laravel\framework\src\Illuminate\Foundation\Providers/../resources/exceptions/renderer/components/icons/check.blade.php ENDPATH**/ ?>